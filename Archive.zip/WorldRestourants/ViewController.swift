//
//  ViewController.swift
//  WorldRestourants
//
//  Created by Aitzhan Ramazan on 09.07.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

